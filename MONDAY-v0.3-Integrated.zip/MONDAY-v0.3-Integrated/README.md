# MONDAY Android v0.3 — Integrated Local Assistant

A single Android project for the MONDAY assistant. Built with Kotlin, Jetpack Compose and Android SDK (min API 26 / target API 35).

## Working in this build
- Futuristic dark-blue MONDAY dashboard with date/time and British-English Android text-to-speech greeting.
- Local reminders: create, choose date/time, schedule Android alarm notifications, delete/cancel.
- Local notes: create, list and delete.
- Local calendar: create, list and delete personal events with date/time and optional location.
- Local data stored on the device using SharedPreferences + JSON; no account or cloud sync required.
- Android 13+ notification permission request.
- GitHub Actions workflow to build a debug APK.

## Integrations that need setup before they can work
- Online AI chat: needs an AI provider and preferably a small secure backend/proxy. Do not put a private API secret directly in a public Android app or GitHub repository.
- Live weather: internet permission is included; a weather/geocoding service and UI integration still need to be configured.
- Google Calendar sync: needs Google sign-in, OAuth configuration and user consent. The current calendar is local-only.
- Always-on “Hey MONDAY” wake word: needs a microphone foreground service, runtime permission, battery/privacy handling and testing on the target phone. Not enabled in this build.
- Offline AI: needs a compatible on-device model download and inference runtime. Not bundled in this APK/project.
- App/device control: Android only permits specific actions and permissions; unrestricted phone control is not possible for ordinary apps.

These integrations are intentionally identified as not yet active; the app does not pretend they are operational without their required services and permissions.

## Build
The included GitHub Actions workflow builds a debug APK when pushed to `main`, or when manually run from the Actions tab. Build environment: JDK 17, Gradle, Android Gradle Plugin from the project build files.

## Project
- `app/src/main/java/com/monday/assistant/MainActivity.kt` — dashboard and screens
- `data/LocalStore.kt` — on-device persistence
- `data/Reminder.kt`, `data/Note.kt`, `data/CalendarEvent.kt` — local data models
- `reminders/ReminderReceiver.kt` — reminder notification receiver
- `.github/workflows/android.yml` — APK build workflow
