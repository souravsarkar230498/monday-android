# MONDAY Android — integrated assistant build

This project integrates the Android app with the existing Cloudflare Worker and adds local assistant capabilities. This is source package v1.5.1 / app version 1.0.0-beta2; it remains a development build until GitHub Actions and a real-device test pass.

## Included in this integration

- Futuristic MONDAY dashboard and British English system TTS (voice gender depends on the phone's installed voice engine).
- Gemini-powered chat through the existing Cloudflare Worker `/chat` endpoint. The Gemini API key remains a Cloudflare Secret and is not packaged in Android.
- Tap-to-talk speech recognition using the Android speech recognizer; recognized text is sent to MONDAY. The app answers using TTS.
- Offline `Hey Jarvis` wake-word detection using openWakeWord. When MONDAY is visible, detection starts speech recognition; when the app is backgrounded, the notification can reopen MONDAY to continue. Android background microphone restrictions and realme battery behaviour still require device testing.
- Local time/date/battery/app-launch/search/alarm commands.
- Local notes, tasks, reminders and calendar events. The Reminders tab is exposed in the main navigation. Future reminders are restored after device reboot, app replacement, and system time/time-zone changes.
- Device calendar import/export through Android Calendar Provider, with separate runtime permission flows for reading and writing. Calendars configured on the phone (including Google calendars that sync to the device) are accessible after permission; this is not Google OAuth or a separate cloud sync implementation.
- Weather lookup through Open-Meteo geocoding and forecast APIs. No API key is required for non-commercial use; attribution is shown in the app.
- Optional notification reading through Android Notification Listener. User must grant Notification Access manually; the latest saved notifications can also be read aloud with “read my notifications”.
- Optional offline GGUF model inference through llama.cpp Android AAR. The model is not bundled. Settings can download Qwen2.5 0.5B Instruct Q4_K_M (~398 MB) or import a compatible GGUF file. Offline responses are a fallback when online AI is unavailable.
- Persistent local chat history, notes, tasks, reminders and events.

## Required services / costs

- Cloudflare Worker and the already-configured `GEMINI_API_KEY` secret are required for online Gemini chat. Gemini usage is subject to the user's Google AI plan/rate limits; the key must never be placed in the APK.
- Open-Meteo requires no key and offers a free non-commercial API subject to its usage terms and attribution requirements.
- Offline model download is approximately 398 MB and requires storage/data. Qwen2.5-0.5B-Instruct is Apache-2.0 licensed.
- Wake-word library code is Apache-2.0; the bundled openWakeWord pretrained model is CC BY-NC-SA 4.0. This model is for non-commercial use unless separately licensed.
- No subscription/API key is needed for the local notes/tasks/reminders features.

## Important platform limitations

- The available wake-word model is “Hey Jarvis”; a trained custom “Hey MONDAY” model is not included yet. Android 14+ microphone foreground services must be started while the app is visible and require microphone permission plus an ongoing notification. Continuous listening uses battery, and the service is not guaranteed to survive every OEM battery policy or screen-off state.
- Android's standard speech recognizer may use the device's configured recognition provider and may require network access. This is not a fully offline speech-to-text engine.
- Notification access can expose private notification text. It is opt-in and user-controlled.
- Calendar import/export uses the device calendar provider. It does not implement Google OAuth or remote account sync itself.
- The 0.5B offline model is intentionally small for an 8 GB phone; it is less capable than Gemini.

## Build

The included source-root GitHub Actions workflow runs `python3 scripts/preflight.py` before `gradle assembleDebug` and uploads the debug APK as a workflow artifact. The repository-level ZIP-extraction workflow must also run the same preflight step before the Gradle build. Gradle is provisioned by GitHub Actions (Gradle 8.9); no Gradle wrapper is included in this source archive.

GitHub Actions builds the debug APK with JDK 17 and Gradle 8.9. Build success and actual Narzo 70 Pro 5G behaviour must be verified before calling this release complete.
