package com.monday.assistant.data

data class CalendarEvent(
    val id: Int = 0,
    val title: String,
    val description: String = "",
    val startTime: Long,
    val endTime: Long = 0L,
    val location: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
