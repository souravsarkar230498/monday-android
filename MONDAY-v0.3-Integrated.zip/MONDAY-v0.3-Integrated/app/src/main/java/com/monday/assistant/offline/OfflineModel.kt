package com.monday.assistant.offline

import android.content.Context
import dev.ffmpegkit.llama.Llama
import dev.ffmpegkit.llama.LlamaConfig
import dev.ffmpegkit.llama.LlamaModel
import java.io.File

/** Optional local GGUF model runtime. The model is deliberately not bundled in the APK. */
class OfflineModel(private val context: Context) {
    private var model: LlamaModel? = null
    private val modelFile: File get() = File(context.getExternalFilesDir("models"), "monday-model.gguf")

    fun isModelPresent(): Boolean = modelFile.exists() && modelFile.length() > 100_000_000L
    fun modelPath(): String = modelFile.absolutePath

    suspend fun load(): Boolean {
        if (!isModelPresent()) return false
        if (model == null) model = Llama.loadModel(modelPath = modelFile.absolutePath, config = LlamaConfig(contextSize = 2048, threads = 4))
        return true
    }

    suspend fun ask(prompt: String, history: List<Pair<String, String>> = emptyList()): String {
        val loaded = model ?: throw IllegalStateException("Load a GGUF model first.")
        val transcript = history.takeLast(8).joinToString("\n") { (role, text) ->
            (if (role == "user") "User" else "MONDAY") + ": " + text
        }
        val fullPrompt = (if (transcript.isBlank()) "" else "$transcript\n") + "User: $prompt\nMONDAY:"
        return Llama.complete(loaded, prompt = fullPrompt, systemPrompt = "You are MONDAY, a concise British English personal assistant. Address the user as Sir.", maxTokens = 256).text
    }

    fun release() {
        model?.let { Llama.releaseModel(it) }
        model = null
    }
}
