package com.monday.assistant.calendar

import android.content.ContentValues
import android.content.Context
import android.provider.CalendarContract
import com.monday.assistant.data.CalendarEvent

/** Imports/exports events through Android's calendar provider. Google calendars sync if configured on the phone. */
class DeviceCalendarSync(private val context: Context) {
    fun importEvents(): List<CalendarEvent> {
        val rows = mutableListOf<CalendarEvent>()
        val projection = arrayOf(CalendarContract.Events._ID, CalendarContract.Events.TITLE, CalendarContract.Events.DESCRIPTION, CalendarContract.Events.DTSTART, CalendarContract.Events.DTEND, CalendarContract.Events.EVENT_LOCATION)
        context.contentResolver.query(CalendarContract.Events.CONTENT_URI, projection, "${CalendarContract.Events.DTSTART} >= ?", arrayOf((System.currentTimeMillis() - 86_400_000L).toString()), "${CalendarContract.Events.DTSTART} ASC")?.use { c ->
            while (c.moveToNext()) {
                rows += CalendarEvent(c.getLong(0).toInt(), c.getString(1).orEmpty(), c.getString(2).orEmpty(), c.getLong(3), c.getLong(4), c.getString(5).orEmpty())
            }
        }
        return rows
    }

    fun exportEvent(event: CalendarEvent, calendarId: Long): Long {
        val projection = arrayOf(CalendarContract.Events._ID)
        var existingId: Long? = null
        context.contentResolver.query(
            CalendarContract.Events.CONTENT_URI,
            projection,
            "${CalendarContract.Events.CALENDAR_ID} = ? AND ${CalendarContract.Events.TITLE} = ? AND ${CalendarContract.Events.DTSTART} = ?",
            arrayOf(calendarId.toString(), event.title, event.startTime.toString()),
            null
        )?.use { cursor -> if (cursor.moveToFirst()) existingId = cursor.getLong(0) }
        if (existingId != null) return existingId!!
        val values = ContentValues().apply {
            put(CalendarContract.Events.CALENDAR_ID, calendarId)
            put(CalendarContract.Events.TITLE, event.title)
            put(CalendarContract.Events.DESCRIPTION, event.description)
            put(CalendarContract.Events.EVENT_LOCATION, event.location)
            put(CalendarContract.Events.DTSTART, event.startTime)
            put(CalendarContract.Events.DTEND, if (event.endTime > event.startTime) event.endTime else event.startTime + 3_600_000L)
            put(CalendarContract.Events.EVENT_TIMEZONE, java.util.TimeZone.getDefault().id)
        }
        val uri = context.contentResolver.insert(CalendarContract.Events.CONTENT_URI, values) ?: throw IllegalStateException("Could not create calendar event.")
        return uri.lastPathSegment?.toLongOrNull() ?: -1L
    }

    fun writableCalendars(): List<Pair<Long, String>> {
        val out = mutableListOf<Pair<Long, String>>()
        val projection = arrayOf(CalendarContract.Calendars._ID, CalendarContract.Calendars.CALENDAR_DISPLAY_NAME, CalendarContract.Calendars.CALENDAR_ACCESS_LEVEL)
        context.contentResolver.query(CalendarContract.Calendars.CONTENT_URI, projection, null, null, null)?.use { c ->
            while (c.moveToNext()) if (c.getInt(2) >= CalendarContract.Calendars.CAL_ACCESS_CONTRIBUTOR) out += c.getLong(0) to c.getString(1).orEmpty()
        }
        return out
    }
}
