package com.monday.assistant.weather

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

 data class WeatherSnapshot(
    val place: String,
    val temperature: Double,
    val feelsLike: Double,
    val humidity: Int,
    val windKmh: Double,
    val code: Int
)

class WeatherClient {
    suspend fun current(city: String): WeatherSnapshot = withContext(Dispatchers.IO) {
        require(city.isNotBlank()) { "Enter a city name." }
        val encoded = URLEncoder.encode(city.trim(), "UTF-8")
        val geo = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=$encoded&count=1&language=en&format=json"))
        val first = geo.optJSONArray("results")?.optJSONObject(0) ?: throw IllegalStateException("I couldn't find that city.")
        val lat = first.getDouble("latitude")
        val lon = first.getDouble("longitude")
        val place = listOf(first.optString("name"), first.optString("admin1"), first.optString("country")).filter { it.isNotBlank() }.distinct().joinToString(", ")
        val forecast = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&timezone=auto"))
        val current = forecast.getJSONObject("current")
        WeatherSnapshot(place, current.getDouble("temperature_2m"), current.getDouble("apparent_temperature"), current.getInt("relative_humidity_2m"), current.getDouble("wind_speed_10m"), current.getInt("weather_code"))
    }

    private fun get(address: String): String {
        val c = URL(address).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 15_000; c.readTimeout = 20_000
            c.setRequestProperty("Accept", "application/json")
            if (c.responseCode !in 200..299) throw IllegalStateException("Weather service returned HTTP ${c.responseCode}.")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    companion object {
        fun description(code: Int): String = when (code) {
            0 -> "Clear sky"; 1, 2 -> "Mainly clear"; 3 -> "Cloudy"; 45, 48 -> "Fog"
            51, 53, 55 -> "Drizzle"; 56, 57 -> "Freezing drizzle"; 61, 63, 65 -> "Rain"
            66, 67 -> "Freezing rain"; 71, 73, 75, 77 -> "Snow"; 80, 81, 82 -> "Rain showers"
            85, 86 -> "Snow showers"; 95, 96, 99 -> "Thunderstorm"; else -> "Weather unavailable"
        }
    }
}
