package com.monday.assistant.reminders

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.monday.assistant.data.LocalStore

/** Android clears AlarmManager alarms after reboot; restore future MONDAY reminders. */
class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != Intent.ACTION_BOOT_COMPLETED &&
            intent?.action != Intent.ACTION_MY_PACKAGE_REPLACED &&
            intent?.action != Intent.ACTION_TIME_CHANGED &&
            intent?.action != Intent.ACTION_TIMEZONE_CHANGED) return

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        LocalStore(context).getReminders()
            .filter { !it.isCompleted && it.triggerTime > now }
            .forEach { reminder ->
                val alarmIntent = Intent(context, ReminderReceiver::class.java)
                    .putExtra("title", reminder.title)
                val pending = PendingIntent.getBroadcast(
                    context,
                    reminder.id,
                    alarmIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.triggerTime, pending)
            }
    }
}
