package com.monday.assistant.wakeword

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.util.Log
import com.monday.assistant.MainActivity
import com.openwakeword.OpenWakeWord
import java.util.Locale

/** Foreground microphone service for offline "Hey Jarvis" detection. */
class WakeWordService : Service(), TextToSpeech.OnInitListener {
    private var detector: OpenWakeWord? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        tts = TextToSpeech(this, this)
        val power = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MONDAY:WakeWord")?.apply { setReferenceCounted(false); acquire() }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        if (detector == null) {
            try {
                detector = OpenWakeWord.Builder(applicationContext)
                    .setModel(OpenWakeWord.BuiltInModel.HEY_JARVIS)
                    .setThreshold(0.65f)
                    .setDebounceMs(3000L)
                    .build()
                detector?.start { score ->
                    Log.i(TAG, "Hey Jarvis detected, score=$score")
                    detector?.stop()
                    detector?.release()
                    detector = null
                    getSharedPreferences("monday_local_data", MODE_PRIVATE).edit().putBoolean("wake_detected", true).apply()
                    sendBroadcast(Intent(ACTION_WAKE_DETECTED).setPackage(packageName))
                    speak("At your service, Sir.")
                    updateNotification("Wake word detected — open MONDAY to speak")
                }
            } catch (error: Exception) {
                Log.e(TAG, "Unable to start wake-word detector", error)
                stopSelf()
            }
        }
        return START_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale.UK
            val britishMale = tts?.voices?.firstOrNull { it.locale.language == "en" && it.locale.country == "GB" && it.name.contains("male", ignoreCase = true) }
            if (britishMale != null) tts?.voice = britishMale
            tts?.setSpeechRate(0.88f)
        }
    }

    private fun speak(message: String) {
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "MONDAY_WAKE_WORD")
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "MONDAY wake-word listening", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String = "Listening offline for ‘Hey Jarvis’") : Notification {
        val openApp = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("MONDAY is listening")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(openApp)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("MONDAY is listening")
                .setContentText(message)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(openApp)
                .setOngoing(true)
                .build()
        }
    }

    private fun updateNotification(message: String) {
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(message))
    }

    override fun onDestroy() {
        detector?.stop()
        detector?.release()
        detector = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        if (wakeLock?.isHeld == true) wakeLock?.release()
        wakeLock = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.monday.assistant.wakeword.START"
        const val ACTION_STOP = "com.monday.assistant.wakeword.STOP"
        const val ACTION_WAKE_DETECTED = "com.monday.assistant.wakeword.DETECTED"
        private const val TAG = "MondayWakeWord"
        private const val CHANNEL_ID = "monday_wake_word"
        private const val NOTIFICATION_ID = 7102
    }
}
