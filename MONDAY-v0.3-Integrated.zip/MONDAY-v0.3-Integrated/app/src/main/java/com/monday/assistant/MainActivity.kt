package com.monday.assistant

import android.Manifest
import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.DownloadManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.monday.assistant.ai.WorkerClient
import com.monday.assistant.calendar.DeviceCalendarSync
import com.monday.assistant.core.MondayConfig
import com.monday.assistant.data.CalendarEvent
import com.monday.assistant.data.LocalStore
import com.monday.assistant.data.Note
import com.monday.assistant.data.Reminder
import com.monday.assistant.data.Task
import com.monday.assistant.notifications.MondayNotificationListener
import com.monday.assistant.offline.OfflineModel
import com.monday.assistant.reminders.ReminderReceiver
import com.monday.assistant.wakeword.WakeWordService
import com.monday.assistant.weather.WeatherClient
import com.monday.assistant.weather.WeatherSnapshot
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var restartWakeAfterSpeech = false
    private lateinit var store: LocalStore
    private lateinit var offlineModel: OfflineModel
    private val worker = WorkerClient()
    private val weatherClient = WeatherClient()
    private var activityVisible = false
    private var awaitingSpeechResult = false

    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val microphonePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) launchSpeechRecognition() else speak("Microphone permission is required, Sir.")
    }
    private val wakeWordPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startWakeWordService() else speak("Microphone permission is required for hands-free listening, Sir.")
    }
    private val speechLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        awaitingSpeechResult = false
        val spoken = if (result.resultCode == RESULT_OK) result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() else null
        if (!spoken.isNullOrBlank()) sendToAI(spoken)
        else if (getSharedPreferences("monday_local_data", MODE_PRIVATE).getBoolean("wake_enabled", false)) startWakeWordService(silent = true)
    }
    private val modelPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) copyModel(uri)
    }
    private val calendarReadPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) importDeviceCalendarNow() else speak("Calendar read permission was not granted, Sir.")
    }
    private val calendarWritePermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) exportDeviceCalendarNow() else speak("Calendar write permission was not granted, Sir.")
    }

    private val wakeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == WakeWordService.ACTION_WAKE_DETECTED && activityVisible) {
                getSharedPreferences("monday_local_data", MODE_PRIVATE).edit().putBoolean("wake_detected", false).apply()
                Handler(Looper.getMainLooper()).postDelayed({ if (activityVisible) launchSpeechRecognition() }, 2200L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        store = LocalStore(this)
        offlineModel = OfflineModel(this)
        createReminderChannel()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        val filter = IntentFilter(WakeWordService.ACTION_WAKE_DETECTED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(wakeReceiver, filter, Context.RECEIVER_NOT_EXPORTED) else @Suppress("DEPRECATION") registerReceiver(wakeReceiver, filter)
        setContent {
            MondayApp(
                store = store,
                speak = ::speak,
                onVoiceInput = ::startListening,
                onWakeWordStart = ::enableWakeWord,
                onWakeWordStop = ::disableWakeWord,
                onSendMessage = { text, done -> sendToAI(text, done) },
                onWeather = { city, done -> lifecycleScope.launch { done(runCatching { weatherClient.current(city) }) } },
                onImportCalendar = ::importDeviceCalendar,
                onExportCalendar = ::exportDeviceCalendar,
                onDownloadOfflineModel = ::downloadOfflineModel,
                onOpenNotificationAccess = { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
                onOpenModelPicker = { modelPicker.launch(arrayOf("application/octet-stream", "application/x-gguf", "*/*")) },
                onLoadOfflineModel = { lifecycleScope.launch { runCatching { offlineModel.load() }.onSuccess { speak(if (it) "Offline model is ready, Sir." else "Please select a GGUF model file first, Sir.") }.onFailure { speak("I could not load the offline model, Sir.") } } },
                offlineModelPresent = offlineModel.isModelPresent()
            )
        }
    }

    override fun onResume() {
        super.onResume(); activityVisible = true
        val prefs = getSharedPreferences("monday_local_data", MODE_PRIVATE)
        if (prefs.getBoolean("wake_detected", false)) {
            prefs.edit().putBoolean("wake_detected", false).apply()
            if (prefs.getBoolean("wake_enabled", false)) Handler(Looper.getMainLooper()).postDelayed({ if (activityVisible) launchSpeechRecognition() }, 500L)
        } else if (prefs.getBoolean("wake_enabled", false) && !awaitingSpeechResult && tts?.isSpeaking != true) {
            Handler(Looper.getMainLooper()).post { if (activityVisible) startWakeWordService(silent = true) }
        }
    }
    override fun onPause() { activityVisible = false; super.onPause() }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale.UK
            val britishMale = tts?.voices?.firstOrNull { it.locale.language == "en" && it.locale.country == "GB" && it.name.contains("male", ignoreCase = true) }
            if (britishMale != null) tts?.voice = britishMale
            tts?.setSpeechRate(0.88f)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == "MONDAY_AI_REPLY" && activityVisible && getSharedPreferences("monday_local_data", MODE_PRIVATE).getBoolean("wake_enabled", false)) {
                        Handler(Looper.getMainLooper()).post { if (activityVisible) startWakeWordService(silent = true) }
                    }
                }
                @Deprecated("Deprecated in Java") override fun onError(utteranceId: String?) = Unit
            })
        }
    }

    private fun speak(message: String) {
        if (ttsReady) {
            val id = if (restartWakeAfterSpeech) "MONDAY_AI_REPLY" else "MONDAY_SPEECH"
            restartWakeAfterSpeech = false
            tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, id)
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
        else launchSpeechRecognition()
    }

    private fun enableWakeWord() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) wakeWordPermission.launch(Manifest.permission.RECORD_AUDIO)
        else startWakeWordService()
    }

    private fun startWakeWordService(silent: Boolean = false) {
        val intent = Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_START)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(intent) else startService(intent)
        getSharedPreferences("monday_local_data", MODE_PRIVATE).edit().putBoolean("wake_enabled", true).apply()
        if (!silent) speak("Hands-free listening is enabled, Sir.")
    }

    private fun disableWakeWord() {
        stopService(Intent(this, WakeWordService::class.java))
        getSharedPreferences("monday_local_data", MODE_PRIVATE).edit().putBoolean("wake_enabled", false).apply()
        speak("Wake-word listening stopped, Sir.")
    }

    private fun launchSpeechRecognition() {
        awaitingSpeechResult = true
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-GB")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "I'm listening, Sir.")
        }
        try { speechLauncher.launch(intent) } catch (_: Exception) {
            awaitingSpeechResult = false
            speak("Speech recognition is unavailable on this device, Sir.")
            if (getSharedPreferences("monday_local_data", MODE_PRIVATE).getBoolean("wake_enabled", false)) startWakeWordService(silent = true)
        }
    }

    private fun sendToAI(message: String, onReply: (String) -> Unit = {}) {
        val clean = message.trim()
        if (clean.isEmpty()) return
        val localReply = handleLocalCommand(clean)
        if (localReply != null) {
            store.appendChat("user", clean)
            store.appendChat("model", localReply)
            restartWakeAfterSpeech = getSharedPreferences("monday_local_data", MODE_PRIVATE).getBoolean("wake_enabled", false)
            speak(localReply)
            onReply(localReply)
            return
        }
        val history = store.getChatHistory()
        store.appendChat("user", clean)
        lifecycleScope.launch {
            val offlinePreferred = getSharedPreferences("monday_local_data", MODE_PRIVATE).getBoolean("offline_mode", false)
            val reply = if (offlinePreferred) {
                runCatching { if (offlineModel.load()) offlineModel.ask(clean, history) else "Please download or import a GGUF model first, Sir." }.getOrElse { "Offline AI could not start: ${it.message}" }
            } else {
                runCatching { worker.chat(clean, history) }.getOrElse { error ->
                    runCatching { if (offlineModel.load()) offlineModel.ask(clean, history) else null }.getOrNull()
                        ?: "I couldn't reach my online AI brain. ${error.message ?: "Please check your internet connection."}"
                }
            }
            store.appendChat("model", reply)
            restartWakeAfterSpeech = getSharedPreferences("monday_local_data", MODE_PRIVATE).getBoolean("wake_enabled", false)
            speak(reply)
            onReply(reply)
        }
    }

    private fun handleLocalCommand(raw: String): String? {
        val command = raw.lowercase(Locale.UK).trim()
        return when {
            (command == "time" || command.contains("what time") || command.contains("tell me the time") || command.startsWith("time ")) -> "The time is ${SimpleDateFormat("h:mm a", Locale.UK).format(Date())}, Sir."
            (command == "date" || command.contains("what is the date") || command.contains("what's the date") || command == "today") -> "Today is ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.UK).format(Date())}, Sir."
            command.contains("battery") -> {
                val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level = battery?.getIntExtra("level", -1) ?: -1
                val scale = battery?.getIntExtra("scale", 100) ?: 100
                if (level >= 0) "Battery level is ${level * 100 / scale} percent, Sir." else "I cannot read the battery level, Sir."
            }
            command.contains("read my notifications") || command.contains("read notifications") || command.contains("any notifications") -> {
                val recent = store.getRecentNotifications().take(5)
                if (recent.isEmpty()) "There are no saved notifications, Sir. Please enable MONDAY Notification Access in settings if you would like me to read them."
                else "Here are your latest notifications, Sir. " + recent.joinToString(". ") { row ->
                    val title = row.optString("title").ifBlank { row.optString("app") }
                    val body = row.optString("body")
                    if (body.isBlank()) title else "$title: $body"
                }
            }
            command.startsWith("open ") -> {
                val target = command.removePrefix("open ").trim()
                val packageName = when {
                    target.contains("youtube") -> "com.google.android.youtube"
                    target.contains("chrome") -> "com.android.chrome"
                    target.contains("whatsapp") -> "com.whatsapp"
                    target.contains("settings") -> "com.android.settings"
                    target.contains("camera") -> "com.android.camera2"
                    else -> ""
                }
                val launch = if (packageName.isNotEmpty()) packageManager.getLaunchIntentForPackage(packageName) else null
                if (launch != null) { startActivity(launch); "Opening $target, Sir." } else "I couldn't find that app, Sir."
            }
            command.startsWith("search ") -> {
                val query = raw.substringAfter("search", "").trim()
                if (query.isNotBlank()) { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query)))); "Searching the web, Sir." } else "What would you like me to search for, Sir?"
            }
            command.startsWith("set an alarm") || command.startsWith("wake me") -> {
                val match = Regex("(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?").find(command)
                if (match != null) {
                    var hour = match.groupValues[1].toIntOrNull() ?: 7
                    val minute = match.groupValues[2].toIntOrNull() ?: 0
                    when (match.groupValues[3]) { "pm" -> if (hour < 12) hour += 12; "am" -> if (hour == 12) hour = 0 }
                    startActivity(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour).putExtra(AlarmClock.EXTRA_MINUTES, minute).putExtra(AlarmClock.EXTRA_MESSAGE, "MONDAY alarm"))
                    "Opening the alarm screen, Sir."
                } else "Please say the alarm time, for example, set an alarm for seven AM."
            }
            else -> null
        }
    }

    private fun copyModel(uri: Uri) {
        lifecycleScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    val dir = getExternalFilesDir("models") ?: error("Model storage is unavailable")
                    if (!dir.exists()) dir.mkdirs()
                    val target = File(dir, "monday-model.gguf")
                    contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use { input.copyTo(it) } } ?: error("Could not read selected file")
                    if (target.length() <= 100_000_000L) { target.delete(); error("The selected file is too small to be a GGUF language model.") }
                }
            }.onSuccess { speak("Offline model file imported, Sir. You can now load it in settings.") }
                .onFailure { speak("Model import failed, Sir. ${it.message}") }
        }
    }

    private fun importDeviceCalendar() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            calendarReadPermission.launch(Manifest.permission.READ_CALENDAR); return
        }
        importDeviceCalendarNow()
    }

    private fun importDeviceCalendarNow() {
        lifecycleScope.launch {
            runCatching { withContext(Dispatchers.IO) { DeviceCalendarSync(this@MainActivity).importEvents() } }.onSuccess { rows ->
                rows.forEach { store.saveEvent(it.copy(id = (it.id.toLong() xor it.startTime).toInt())) }
                speak("Imported ${rows.size} calendar events, Sir.")
            }.onFailure { speak("Calendar import failed. Please check calendar permission, Sir.") }
        }
    }

    private fun exportDeviceCalendar() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_CALENDAR) != PackageManager.PERMISSION_GRANTED) {
            calendarWritePermission.launch(Manifest.permission.WRITE_CALENDAR); return
        }
        exportDeviceCalendarNow()
    }

    private fun exportDeviceCalendarNow() {
        lifecycleScope.launch {
            runCatching {
                withContext(Dispatchers.IO) {
                    val sync = DeviceCalendarSync(this@MainActivity)
                    val calendar = sync.writableCalendars().firstOrNull() ?: error("No writable calendar found on this phone.")
                    store.getEvents().forEach { sync.exportEvent(it, calendar.first) }
                    store.getEvents().size
                }
            }.onSuccess { speak("Exported $it local events to your phone calendar, Sir.") }
                .onFailure { speak("Calendar export failed. ${it.message}") }
        }
    }

    private fun downloadOfflineModel() {
        getExternalFilesDir("models")?.mkdirs()
        val request = DownloadManager.Request(Uri.parse("https://huggingface.co/bartowski/Qwen2.5-0.5B-Instruct-GGUF/resolve/main/Qwen2.5-0.5B-Instruct-Q4_K_M.gguf"))
            .setTitle("MONDAY Offline AI Model")
            .setDescription("Downloading Qwen2.5 0.5B Q4 GGUF model (~398 MB)")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)
            .setDestinationInExternalFilesDir(this, "models", "monday-model.gguf")
        (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
        speak("Downloading the offline AI model. It is approximately 398 megabytes, Sir.")
    }

    private fun createReminderChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(MondayConfig.REMINDER_CHANNEL_ID, MondayConfig.REMINDER_CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH)
        )
    }

    private fun scheduleReminder(reminder: Reminder) {
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("title", reminder.title)
        val pending = PendingIntent.getBroadcast(this, reminder.id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.triggerTime, pending)
    }

    private fun cancelReminder(id: Int) {
        val pending = PendingIntent.getBroadcast(this, id, Intent(this, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if (pending != null) (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(wakeReceiver) }
        offlineModel.release()
        tts?.stop(); tts?.shutdown(); super.onDestroy()
    }
}

@Composable
private fun MondayApp(
    store: LocalStore,
    speak: (String) -> Unit,
    onVoiceInput: () -> Unit,
    onWakeWordStart: () -> Unit,
    onWakeWordStop: () -> Unit,
    onSendMessage: (String, (String) -> Unit) -> Unit,
    onWeather: (String, (Result<WeatherSnapshot>) -> Unit) -> Unit,
    onImportCalendar: () -> Unit,
    onExportCalendar: () -> Unit,
    onDownloadOfflineModel: () -> Unit,
    onOpenNotificationAccess: () -> Unit,
    onOpenModelPicker: () -> Unit,
    onLoadOfflineModel: () -> Unit,
    offlineModelPresent: Boolean
) {
    val cyan = Color(MondayConfig.THEME_PRIMARY)
    val background = Color(MondayConfig.THEME_BACKGROUND)
    var page by remember { mutableStateOf("HOME") }
    var reminders by remember { mutableStateOf(store.getReminders()) }
    var notes by remember { mutableStateOf(store.getNotes()) }
    var events by remember { mutableStateOf(store.getEvents()) }
    var tasks by remember { mutableStateOf(store.getTasks()) }
    var chat by remember { mutableStateOf(store.getChatHistory()) }
    var reminderTitle by remember { mutableStateOf("") }
    var selectedTime by remember { mutableLongStateOf(0L) }
    var noteTitle by remember { mutableStateOf("") }
    var noteContent by remember { mutableStateOf("") }
    var taskTitle by remember { mutableStateOf("") }
    var eventTitle by remember { mutableStateOf("") }
    var eventLocation by remember { mutableStateOf("") }
    var eventTime by remember { mutableLongStateOf(0L) }
    var message by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current
    var city by remember { mutableStateOf("Kolkata") }
    var offlineMode by remember { mutableStateOf(context.getSharedPreferences("monday_local_data", Context.MODE_PRIVATE).getBoolean("offline_mode", false)) }
    var weather by remember { mutableStateOf<WeatherSnapshot?>(null) }
    var weatherError by remember { mutableStateOf("") }
    val scroll = rememberScrollState()
    val reminderFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }

    LaunchedEffect(page) {
        if (page == "CHAT") chat = store.getChatHistory()
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = cyan, background = background, surface = Color(0xFF081827), onSurface = Color.White)) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF061B2D), background, Color.Black))).padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("MONDAY", color = cyan, fontSize = 27.sp, fontWeight = FontWeight.Light, letterSpacing = 6.sp)
                    Text("PERSONAL AI SYSTEM  •  v1.0 BETA 2", color = Color(0xFF8AAFC4), fontSize = 9.sp, letterSpacing = 1.5.sp)
                }
                Text("● SYSTEM READY", color = Color(0xFF67E6B2), fontSize = 10.sp)
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("HOME", "CHAT", "WEATHER", "TASKS", "REMINDERS", "NOTES", "CALENDAR", "ALERTS", "SETTINGS").forEach { tab ->
                    FilterChip(selected = page == tab, onClick = { page = tab }, label = { Text(tab, fontSize = 9.sp) })
                }
            }
            Spacer(Modifier.height(8.dp))
            when (page) {
                "HOME" -> Column(Modifier.weight(1f).verticalScroll(scroll), horizontalAlignment = Alignment.CenterHorizontally) {
                    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xCC071B2B)), border = BorderStroke(1.dp, Color(0x5539D8FF))) {
                        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Box(Modifier.size(154.dp).background(Brush.radialGradient(listOf(Color(0x6639D8FF), Color(0x2239D8FF), Color.Transparent)), CircleShape), contentAlignment = Alignment.Center) {
                                Box(Modifier.size(112.dp).background(Color(0xFF0B3047), CircleShape), contentAlignment = Alignment.Center) { Text("M", color = cyan, fontSize = 66.sp, fontWeight = FontWeight.ExtraLight) }
                            }
                            Text("MONDAY CORE", color = cyan, letterSpacing = 3.sp, fontSize = 11.sp)
                            Text("Awaiting your command, Sir.", color = Color(0xFF8AAFC4), fontSize = 13.sp)
                            Spacer(Modifier.height(12.dp))
                            Button(onClick = onVoiceInput, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("🎙  TALK TO MONDAY") }
                            OutlinedButton(onClick = onWakeWordStart, modifier = Modifier.fillMaxWidth()) { Text("ENABLE HEY JARVIS (OFFLINE)") }
                            OutlinedButton(onClick = onWakeWordStop, modifier = Modifier.fillMaxWidth()) { Text("STOP WAKE-WORD LISTENING") }
                            OutlinedButton(onClick = { speak("At your service, Sir. MONDAY systems are online.") }, modifier = Modifier.fillMaxWidth()) { Text("SUMMON MONDAY") }
                            Text(SimpleDateFormat("EEEE, dd MMMM yyyy  •  hh:mm a", Locale.UK).format(Date()), color = Color(0xFF8AAFC4), fontSize = 11.sp)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("QUICK STATUS", color = cyan, letterSpacing = 2.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatusCard("TASKS", tasks.count { !it.isDone }.toString(), Modifier.weight(1f))
                        StatusCard("REMINDERS", reminders.size.toString(), Modifier.weight(1f))
                        StatusCard("NOTES", notes.size.toString(), Modifier.weight(1f))
                    }
                    Text("Online Gemini AI • Optional offline GGUF model • Local notes, tasks and reminders", color = Color(0xFF8AAFC4), fontSize = 11.sp)
                }
                "CHAT" -> Column(Modifier.weight(1f)) {
                    Text("AI CONVERSATION", color = cyan, letterSpacing = 2.sp)
                    LazyColumn(Modifier.weight(1f), reverseLayout = false) {
                        items(chat, key = { it.first + it.second.hashCode() + chat.indexOf(it) }) { (role, text) ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 3.dp), colors = CardDefaults.cardColors(containerColor = if (role == "user") Color(0xFF123B54) else Color(0xFF102638))) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(if (role == "user") "YOU" else "MONDAY", color = cyan, fontSize = 9.sp, letterSpacing = 1.sp)
                                    Text(text, color = Color.White, fontSize = 14.sp)
                                }
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(message, { message = it }, Modifier.weight(1f), placeholder = { Text("Ask MONDAY, Sir...") })
                        IconButton(onClick = onVoiceInput) { Text("🎙") }
                        Button(onClick = { val text = message.trim(); if (text.isNotEmpty()) { chat = chat + ("user" to text); message = ""; onSendMessage(text) { chat = store.getChatHistory() } } }) { Text("SEND") }
                    }
                    Text("Replies are saved locally. Online chat uses your Cloudflare Worker; offline fallback needs a GGUF model.", color = Color(0xFF8AAFC4), fontSize = 9.sp)
                }
                "WEATHER" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Text("LIVE WEATHER", color = cyan, letterSpacing = 2.sp)
                    OutlinedTextField(city, { city = it }, Modifier.fillMaxWidth(), label = { Text("City") })
                    Button(onClick = { weatherError = "Loading weather..."; onWeather(city) { result -> result.onSuccess { weather = it; weatherError = "" }.onFailure { weatherError = it.message ?: "Weather unavailable." } } }, modifier = Modifier.fillMaxWidth()) { Text("GET WEATHER") }
                    weather?.let { w ->
                        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFF102638))) {
                            Column(Modifier.padding(16.dp)) {
                                Text(w.place, color = cyan, fontSize = 18.sp)
                                Text("${w.temperature}°C", color = Color.White, fontSize = 42.sp)
                                Text(WeatherClient.description(w.code), color = Color.White)
                                Text("Feels like ${w.feelsLike}°C • Humidity ${w.humidity}% • Wind ${w.windKmh} km/h", color = Color(0xFF8AAFC4))
                            }
                        }
                    }
                    if (weatherError.isNotBlank()) Text(weatherError, color = Color(0xFF8AAFC4))
                    Text("Weather by Open-Meteo", color = Color(0xFF8AAFC4), fontSize = 10.sp)
                }
                "TASKS" -> Column(Modifier.weight(1f)) {
                    Text("TASK MANAGER", color = cyan, letterSpacing = 2.sp)
                    OutlinedTextField(taskTitle, { taskTitle = it }, Modifier.fillMaxWidth(), label = { Text("New task") })
                    Button(onClick = { if (taskTitle.isNotBlank()) { store.saveTask(Task(id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), title = taskTitle.trim())); taskTitle = ""; tasks = store.getTasks() } }, modifier = Modifier.fillMaxWidth()) { Text("ADD TASK") }
                    LazyColumn(Modifier.weight(1f)) { items(tasks, key = { it.id }) { task ->
                        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(task.isDone, { store.saveTask(task.copy(isDone = it)); tasks = store.getTasks() })
                            Text(task.title, Modifier.weight(1f), color = Color.White)
                            TextButton(onClick = { store.deleteTask(task.id); tasks = store.getTasks() }) { Text("DELETE") }
                        }
                    } }
                }
                "REMINDERS" -> Column(Modifier.weight(1f)) {
                    Text("REMINDERS", color = cyan, letterSpacing = 2.sp)
                    OutlinedTextField(reminderTitle, { reminderTitle = it }, Modifier.fillMaxWidth(), label = { Text("Reminder title") })
                    Button(onClick = {
                        val now = Calendar.getInstance()
                        DatePickerDialog(context, { _, y, m, d ->
                            val cal = Calendar.getInstance().apply { set(y, m, d) }
                            TimePickerDialog(context, { _, h, min -> cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, min); cal.set(Calendar.SECOND, 0); selectedTime = cal.timeInMillis }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show()
                        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (selectedTime == 0L) "CHOOSE DATE & TIME" else reminderFormat.format(Date(selectedTime))) }
                    Button(enabled = reminderTitle.isNotBlank() && selectedTime > System.currentTimeMillis(), onClick = {
                        val item = Reminder(id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), title = reminderTitle.trim(), triggerTime = selectedTime)
                        store.saveReminder(item); scheduleReminderFromUi(context, item); reminders = store.getReminders(); reminderTitle = ""; selectedTime = 0L
                    }, modifier = Modifier.fillMaxWidth()) { Text("SAVE REMINDER") }
                    LazyColumn(Modifier.weight(1f)) { items(reminders, key = { it.id }) { item ->
                        Row(Modifier.fillMaxWidth().padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(item.title, color = Color.White); Text(reminderFormat.format(Date(item.triggerTime)), color = cyan, fontSize = 11.sp) }
                            TextButton(onClick = { cancelReminderFromUi(context, item.id); store.deleteReminder(item.id); reminders = store.getReminders() }) { Text("DELETE") }
                        }
                    } }
                }
                "NOTES" -> Column(Modifier.weight(1f)) {
                    Text("NOTES", color = cyan, letterSpacing = 2.sp)
                    OutlinedTextField(noteTitle, { noteTitle = it }, Modifier.fillMaxWidth(), label = { Text("Title") })
                    OutlinedTextField(noteContent, { noteContent = it }, Modifier.fillMaxWidth(), label = { Text("Note") }, minLines = 3)
                    Button(onClick = { if (noteTitle.isNotBlank() && noteContent.isNotBlank()) { store.saveNote(Note(id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), title = noteTitle.trim(), content = noteContent.trim())); notes = store.getNotes(); noteTitle = ""; noteContent = "" } }, modifier = Modifier.fillMaxWidth()) { Text("SAVE NOTE") }
                    LazyColumn(Modifier.weight(1f)) { items(notes, key = { it.id }) { note ->
                        Card(Modifier.fillMaxWidth().padding(4.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF102638))) {
                            Column(Modifier.padding(10.dp)) { Text(note.title, color = cyan, fontWeight = FontWeight.Bold); Text(note.content, color = Color.White); TextButton(onClick = { store.deleteNote(note.id); notes = store.getNotes() }) { Text("DELETE") } }
                        }
                    } }
                }
                "CALENDAR" -> Column(Modifier.weight(1f)) {
                    Text("DEVICE CALENDAR", color = cyan, letterSpacing = 2.sp)
                    OutlinedTextField(eventTitle, { eventTitle = it }, Modifier.fillMaxWidth(), label = { Text("New event title") })
                    OutlinedTextField(eventLocation, { eventLocation = it }, Modifier.fillMaxWidth(), label = { Text("Location (optional)") })
                    Button(onClick = {
                        val now = Calendar.getInstance()
                        DatePickerDialog(context, { _, y, m, d ->
                            val cal = Calendar.getInstance().apply { set(y, m, d) }
                            TimePickerDialog(context, { _, h, min -> cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, min); cal.set(Calendar.SECOND, 0); eventTime = cal.timeInMillis }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show()
                        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (eventTime == 0L) "CHOOSE EVENT DATE & TIME" else reminderFormat.format(Date(eventTime))) }
                    Button(enabled = eventTitle.isNotBlank() && eventTime > 0L, onClick = {
                        store.saveEvent(CalendarEvent(id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), title = eventTitle.trim(), startTime = eventTime, location = eventLocation.trim()))
                        events = store.getEvents(); eventTitle = ""; eventLocation = ""; eventTime = 0L
                    }, modifier = Modifier.fillMaxWidth()) { Text("SAVE LOCAL EVENT") }
                    Divider(color = Color(0x5539D8FF))
                    Button(onClick = onImportCalendar, modifier = Modifier.fillMaxWidth()) { Text("IMPORT FROM PHONE CALENDAR") }
                    OutlinedButton(onClick = { events = store.getEvents() }, modifier = Modifier.fillMaxWidth()) { Text("REFRESH EVENTS") }
                    OutlinedButton(onClick = onExportCalendar, modifier = Modifier.fillMaxWidth()) { Text("EXPORT LOCAL EVENTS TO PHONE CALENDAR") }
                    Text("This reads calendars already configured on Android. If your Google account syncs to this phone, those events can be imported. It is not Google OAuth or cloud sync.", color = Color(0xFF8AAFC4), fontSize = 11.sp)
                    LazyColumn(Modifier.weight(1f)) { items(events, key = { it.id }) { event ->
                        Column(Modifier.fillMaxWidth().padding(8.dp)) { Text(event.title, color = Color.White); Text(reminderFormat.format(Date(event.startTime)), color = cyan, fontSize = 11.sp); if (event.location.isNotBlank()) Text(event.location, color = Color(0xFF8AAFC4)) }
                    } }
                }
                "ALERTS" -> Column(Modifier.weight(1f)) {
                    Text("RECENT NOTIFICATIONS", color = cyan, letterSpacing = 2.sp)
                    Button(onClick = onOpenNotificationAccess, modifier = Modifier.fillMaxWidth()) { Text("GRANT NOTIFICATION ACCESS") }
                    var notifications by remember { mutableStateOf(store.getRecentNotifications()) }
                    OutlinedButton(onClick = { notifications = store.getRecentNotifications() }, modifier = Modifier.fillMaxWidth()) { Text("REFRESH NOTIFICATIONS") }
                    LazyColumn(Modifier.weight(1f)) { items(notifications, key = { it.optLong("time") }) { n ->
                        Card(Modifier.fillMaxWidth().padding(4.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF102638))) {
                            Column(Modifier.padding(10.dp)) { Text(n.optString("app"), color = cyan, fontSize = 9.sp); Text(n.optString("title"), color = Color.White, fontWeight = FontWeight.Bold); Text(n.optString("body"), color = Color(0xFFB8C9D4)) }
                        }
                    } }
                    Text("Notification access is optional and can expose private notification content. Grant it only if you want MONDAY to read notifications.", color = Color(0xFF8AAFC4), fontSize = 10.sp)
                }
                "SETTINGS" -> Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Text("SYSTEM SETTINGS", color = cyan, letterSpacing = 2.sp)
                    Text("ONLINE AI", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Gemini calls go through your Cloudflare Worker. Keep GEMINI_API_KEY only in Cloudflare Secrets; it is not stored in this APK.", color = Color(0xFF8AAFC4), fontSize = 11.sp)
                    Spacer(Modifier.height(14.dp))
                    Text("AI MODE", color = Color.White, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(if (offlineMode) "Offline AI preferred" else "Online Gemini preferred", color = Color(0xFF8AAFC4))
                        Switch(checked = offlineMode, onCheckedChange = { offlineMode = it; context.getSharedPreferences("monday_local_data", Context.MODE_PRIVATE).edit().putBoolean("offline_mode", it).apply() })
                    }
                    Text("OFFLINE AI MODEL", color = Color.White, fontWeight = FontWeight.Bold)
                    Text(if (offlineModelPresent) "GGUF model file detected." else "No GGUF model imported yet. Import a compatible small GGUF model (start with a 0.5B–1.5B Q4 model). Model files are large and are not bundled in the APK.", color = Color(0xFF8AAFC4), fontSize = 11.sp)
                    Button(onClick = onDownloadOfflineModel, modifier = Modifier.fillMaxWidth()) { Text("DOWNLOAD RECOMMENDED 398 MB MODEL") }
                    OutlinedButton(onClick = onOpenModelPicker, modifier = Modifier.fillMaxWidth()) { Text("IMPORT GGUF MODEL FROM STORAGE") }
                    OutlinedButton(onClick = onLoadOfflineModel, modifier = Modifier.fillMaxWidth()) { Text("LOAD OFFLINE MODEL") }
                    Spacer(Modifier.height(12.dp))
                    Text("WAKE WORD", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("The current bundled model listens for ‘Hey Jarvis’. Android requires microphone permission and an ongoing notification. Continuous listening uses extra battery; realme background restrictions still apply.", color = Color(0xFF8AAFC4), fontSize = 11.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("PRIVACY", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("Chat history, notes, tasks and reminders are stored locally. Notification reading is opt-in. Weather uses Open-Meteo without an API key.", color = Color(0xFF8AAFC4), fontSize = 11.sp)
                }
                else -> Unit
            }
        }
    }
}

@Composable
private fun StatusCard(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF102638))) {
        Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(value, color = Color(0xFF39D8FF), fontSize = 22.sp)
            Text(label, color = Color(0xFF8AAFC4), fontSize = 9.sp)
        }
    }
}

private fun scheduleReminderFromUi(context: Context, reminder: Reminder) {
    val intent = Intent(context, ReminderReceiver::class.java).putExtra("title", reminder.title)
    val pending = PendingIntent.getBroadcast(context, reminder.id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.triggerTime, pending)
}

private fun cancelReminderFromUi(context: Context, id: Int) {
    val pending = PendingIntent.getBroadcast(context, id, Intent(context, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
    if (pending != null) (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
}
