package com.monday.assistant

import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.monday.assistant.core.MondayConfig
import com.monday.assistant.data.CalendarEvent
import com.monday.assistant.data.LocalStore
import com.monday.assistant.data.Note
import com.monday.assistant.data.Reminder
import com.monday.assistant.reminders.ReminderReceiver
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        createReminderChannel()
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { MondayApp(LocalStore(this), ::speak, ::scheduleReminder, ::cancelReminder) }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts?.language = Locale.UK
            tts?.setSpeechRate(0.88f)
        }
    }

    private fun speak(message: String) {
        if (ttsReady) tts?.speak(message, TextToSpeech.QUEUE_FLUSH, null, "MONDAY_SPEECH")
    }

    private fun createReminderChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(MondayConfig.REMINDER_CHANNEL_ID, MondayConfig.REMINDER_CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun scheduleReminder(reminder: Reminder) {
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("title", reminder.title)
        val pending = PendingIntent.getBroadcast(this, reminder.id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.triggerTime, pending)
    }

    private fun cancelReminder(id: Int) {
        val pending = PendingIntent.getBroadcast(this, id, Intent(this, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if (pending != null) (getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
    }

    override fun onDestroy() {
        tts?.stop(); tts?.shutdown(); super.onDestroy()
    }
}

@Composable
private fun MondayApp(
    store: LocalStore,
    speak: (String) -> Unit,
    schedule: (Reminder) -> Unit,
    cancel: (Int) -> Unit
) {
    val cyan = Color(MondayConfig.THEME_PRIMARY)
    val background = Color(MondayConfig.THEME_BACKGROUND)
    var page by remember { mutableStateOf("HOME") }
    var reminders by remember { mutableStateOf(store.getReminders()) }
    var notes by remember { mutableStateOf(store.getNotes()) }
    var events by remember { mutableStateOf(store.getEvents()) }
    var eventTitle by remember { mutableStateOf("") }
    var eventLocation by remember { mutableStateOf("") }
    var eventTime by remember { mutableLongStateOf(0L) }
    var reminderTitle by remember { mutableStateOf("") }
    var selectedTime by remember { mutableLongStateOf(0L) }
    var noteTitle by remember { mutableStateOf("") }
    var noteContent by remember { mutableStateOf("") }
    val context = androidx.compose.ui.platform.LocalContext.current
    val dateFormat = remember { SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()) }
    val timeFormat = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val reminderFormat = remember { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()) }

    MaterialTheme(colorScheme = darkColorScheme(primary = cyan, background = background, surface = Color(0xFF081827), onSurface = Color.White)) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF061B2D), background, Color.Black))).padding(18.dp)) {
            Text("MONDAY", color = cyan, fontSize = 29.sp, fontWeight = FontWeight.Light, letterSpacing = 7.sp)
            Text("PERSONAL AI SYSTEM  •  v${MondayConfig.APP_VERSION}", color = Color(0xFF8AAFC4), fontSize = 10.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(14.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0B2638))) {
                Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(88.dp).background(Color(0xFF0E3D59), CircleShape), contentAlignment = Alignment.Center) { Text("M", color = cyan, fontSize = 50.sp, fontWeight = FontWeight.Light) }
                    Text("SYSTEM ONLINE", color = cyan, letterSpacing = 3.sp)
                    Text(dateFormat.format(Date()), color = Color.White)
                    Text(timeFormat.format(Date()), color = Color(0xFF8AAFC4))
                    Button(onClick = { speak("At your service, Sir. MONDAY systems are online.") }) { Text("SUMMON MONDAY") }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                listOf("HOME", "REMINDERS", "NOTES", "CALENDAR").forEach { tab ->
                    FilterChip(selected = page == tab, onClick = { page = tab }, label = { Text(tab) })
                }
            }
            when (page) {
                "REMINDERS" -> {
                    OutlinedTextField(value = reminderTitle, onValueChange = { reminderTitle = it }, label = { Text("Reminder title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        val now = Calendar.getInstance()
                        DatePickerDialog(context, { _, y, m, d ->
                            val cal = Calendar.getInstance().apply { set(y, m, d) }
                            TimePickerDialog(context, { _, h, min ->
                                cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, min); cal.set(Calendar.SECOND, 0)
                                selectedTime = cal.timeInMillis
                            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show()
                        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (selectedTime == 0L) "CHOOSE DATE & TIME" else reminderFormat.format(Date(selectedTime))) }
                    Button(enabled = reminderTitle.isNotBlank() && selectedTime > System.currentTimeMillis(), onClick = {
                        val item = Reminder(id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), title = reminderTitle.trim(), triggerTime = selectedTime)
                        store.saveReminder(item); schedule(item); reminders = store.getReminders(); reminderTitle = ""; selectedTime = 0L
                    }, modifier = Modifier.fillMaxWidth()) { Text("SAVE REMINDER") }
                    LazyColumn(Modifier.weight(1f)) {
                        items(reminders, key = { it.id }) { item ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF102638))) {
                                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) { Text(item.title, color = Color.White); Text(reminderFormat.format(Date(item.triggerTime)), color = cyan, fontSize = 12.sp) }
                                    TextButton(onClick = { cancel(item.id); store.deleteReminder(item.id); reminders = store.getReminders() }) { Text("DELETE") }
                                }
                            }
                        }
                    }
                }
                "CALENDAR" -> {
                    Text("LOCAL CALENDAR", color = cyan, letterSpacing = 2.sp)
                    OutlinedTextField(value = eventTitle, onValueChange = { eventTitle = it }, label = { Text("Event title") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = eventLocation, onValueChange = { eventLocation = it }, label = { Text("Location (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        val now = Calendar.getInstance()
                        DatePickerDialog(context, { _, y, m, d ->
                            val cal = Calendar.getInstance().apply { set(y, m, d) }
                            TimePickerDialog(context, { _, h, min ->
                                cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, min); cal.set(Calendar.SECOND, 0)
                                eventTime = cal.timeInMillis
                            }, now.get(Calendar.HOUR_OF_DAY), now.get(Calendar.MINUTE), false).show()
                        }, now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.DAY_OF_MONTH)).show()
                    }, modifier = Modifier.fillMaxWidth()) { Text(if (eventTime == 0L) "CHOOSE EVENT DATE & TIME" else reminderFormat.format(Date(eventTime))) }
                    Button(enabled = eventTitle.isNotBlank() && eventTime > 0L, onClick = {
                        store.saveEvent(CalendarEvent(id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), title = eventTitle.trim(), startTime = eventTime, location = eventLocation.trim()))
                        events = store.getEvents(); eventTitle = ""; eventLocation = ""; eventTime = 0L
                    }, modifier = Modifier.fillMaxWidth()) { Text("SAVE EVENT") }
                    LazyColumn(Modifier.weight(1f)) {
                        items(events, key = { it.id }) { item ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF102638))) {
                                Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) { Text(item.title, color = Color.White); Text(reminderFormat.format(Date(item.startTime)), color = cyan, fontSize = 12.sp); if (item.location.isNotBlank()) Text(item.location, color = Color(0xFF8AAFC4), fontSize = 12.sp) }
                                    TextButton(onClick = { store.deleteEvent(item.id); events = store.getEvents() }) { Text("DELETE") }
                                }
                            }
                        }
                    }
                }
                "NOTES" -> {
                    OutlinedTextField(value = noteTitle, onValueChange = { noteTitle = it }, label = { Text("Note title") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = noteContent, onValueChange = { noteContent = it }, label = { Text("Write a note") }, modifier = Modifier.fillMaxWidth())
                    Button(enabled = noteTitle.isNotBlank() && noteContent.isNotBlank(), onClick = {
                        store.saveNote(Note(id = (System.currentTimeMillis() % Int.MAX_VALUE).toInt(), title = noteTitle.trim(), content = noteContent.trim()))
                        notes = store.getNotes(); noteTitle = ""; noteContent = ""
                    }, modifier = Modifier.fillMaxWidth()) { Text("SAVE NOTE") }
                    LazyColumn(Modifier.weight(1f)) {
                        items(notes, key = { it.id }) { item ->
                            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF102638))) {
                                Column(Modifier.padding(10.dp)) {
                                    Text(item.title, color = cyan, fontWeight = FontWeight.Bold)
                                    Text(item.content, color = Color.White)
                                    TextButton(onClick = { store.deleteNote(item.id); notes = store.getNotes() }) { Text("DELETE") }
                                }
                            }
                        }
                    }
                }
                else -> {
                    Text("At your service, Sir.", color = Color.White, fontSize = 20.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Your local reminders, notes and calendar are ready. AI chat, live weather, Google Calendar sync, offline language model and wake-word listening need external integrations and are not active yet.", color = Color(0xFF8AAFC4))
                }
            }
            Spacer(Modifier.height(8.dp))
            Text("LOCAL DATA • NOTES, REMINDERS & EVENTS STORED ON THIS DEVICE", color = Color(0xFF64869A), fontSize = 9.sp, letterSpacing = 1.sp)
        }
    }
}
