package com.monday.assistant.data

import android.content.Context
import com.monday.assistant.core.MondayConfig
import org.json.JSONArray
import org.json.JSONObject

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences(MondayConfig.PREFERENCES_NAME, Context.MODE_PRIVATE)

    fun getReminders(): List<Reminder> = read("reminders").mapNotNull { o ->
        val title = o.optString("title")
        if (title.isBlank()) null else Reminder(
            id = o.optInt("id"), title = title, description = o.optString("description"),
            triggerTime = o.optLong("triggerTime"), isCompleted = o.optBoolean("completed"),
            createdAt = o.optLong("createdAt")
        )
    }.sortedBy { it.triggerTime }

    fun saveReminder(item: Reminder) {
        val all = getReminders().toMutableList()
        all.removeAll { it.id == item.id }
        all.add(item)
        write("reminders", all.map { JSONObject()
            .put("id", it.id).put("title", it.title).put("description", it.description)
            .put("triggerTime", it.triggerTime).put("completed", it.isCompleted).put("createdAt", it.createdAt) })
    }

    fun deleteReminder(id: Int) = write("reminders", getReminders().filterNot { it.id == id }.map { reminderJson(it) })

    fun getNotes(): List<Note> = read("notes").mapNotNull { o ->
        val title = o.optString("title")
        if (title.isBlank()) null else Note(o.optInt("id"), title, o.optString("content"), o.optLong("createdAt"), o.optLong("updatedAt"))
    }.sortedByDescending { it.updatedAt }

    fun saveNote(note: Note) {
        val all = getNotes().toMutableList()
        all.removeAll { it.id == note.id }
        all.add(note)
        write("notes", all.map { JSONObject().put("id", it.id).put("title", it.title).put("content", it.content).put("createdAt", it.createdAt).put("updatedAt", it.updatedAt) })
    }

    fun deleteNote(id: Int) = write("notes", getNotes().filterNot { it.id == id }.map {
        JSONObject().put("id", it.id).put("title", it.title).put("content", it.content).put("createdAt", it.createdAt).put("updatedAt", it.updatedAt)
    })


    fun getEvents(): List<CalendarEvent> = read("events").mapNotNull { o ->
        val title = o.optString("title")
        if (title.isBlank()) null else CalendarEvent(
            id = o.optInt("id"), title = title, description = o.optString("description"),
            startTime = o.optLong("startTime"), endTime = o.optLong("endTime"),
            location = o.optString("location"), createdAt = o.optLong("createdAt")
        )
    }.sortedBy { it.startTime }

    fun saveEvent(event: CalendarEvent) {
        val all = getEvents().toMutableList()
        all.removeAll { it.id == event.id }
        all.add(event)
        write("events", all.map { JSONObject().put("id", it.id).put("title", it.title)
            .put("description", it.description).put("startTime", it.startTime)
            .put("endTime", it.endTime).put("location", it.location).put("createdAt", it.createdAt) })
    }

    fun deleteEvent(id: Int) = write("events", getEvents().filterNot { it.id == id }.map {
        JSONObject().put("id", it.id).put("title", it.title).put("description", it.description)
            .put("startTime", it.startTime).put("endTime", it.endTime)
            .put("location", it.location).put("createdAt", it.createdAt)
    })


    fun getTasks(): List<Task> = read("tasks").mapNotNull { o ->
        val title = o.optString("title")
        if (title.isBlank()) null else Task(o.optInt("id"), title, o.optLong("dueTime"), o.optBoolean("done"), o.optLong("createdAt"))
    }.sortedWith(compareBy<Task> { it.isDone }.thenBy { if (it.dueTime == 0L) Long.MAX_VALUE else it.dueTime })

    fun saveTask(task: Task) {
        val all = getTasks().toMutableList()
        all.removeAll { it.id == task.id }; all.add(task)
        write("tasks", all.map { JSONObject().put("id", it.id).put("title", it.title).put("dueTime", it.dueTime).put("done", it.isDone).put("createdAt", it.createdAt) })
    }

    fun deleteTask(id: Int) = write("tasks", getTasks().filterNot { it.id == id }.map { JSONObject().put("id", it.id).put("title", it.title).put("dueTime", it.dueTime).put("done", it.isDone).put("createdAt", it.createdAt) })

    fun getChatHistory(): List<Pair<String, String>> {
        val rows = JSONArray(prefs.getString("chat_history", "[]"))
        return (0 until rows.length()).mapNotNull { i -> rows.optJSONObject(i)?.let { it.optString("role") to it.optString("text") } }
    }

    fun appendChat(role: String, text: String) {
        val all = getChatHistory().toMutableList(); all.add(role to text)
        val json = JSONArray(); all.takeLast(30).forEach { (r, t) -> json.put(JSONObject().put("role", r).put("text", t)) }
        prefs.edit().putString("chat_history", json.toString()).apply()
    }

    fun getRecentNotifications(): List<JSONObject> {
        val rows = JSONArray(prefs.getString("recent_notifications", "[]"))
        return (0 until rows.length()).mapNotNull { rows.optJSONObject(it) }
    }

    private fun reminderJson(r: Reminder) = JSONObject().put("id", r.id).put("title", r.title)
        .put("description", r.description).put("triggerTime", r.triggerTime)
        .put("completed", r.isCompleted).put("createdAt", r.createdAt)

    private fun read(key: String): List<JSONObject> {
        val array = JSONArray(prefs.getString(key, "[]"))
        return (0 until array.length()).mapNotNull { array.optJSONObject(it) }
    }

    private fun write(key: String, rows: List<JSONObject>) {
        val array = JSONArray()
        rows.forEach { array.put(it) }
        prefs.edit().putString(key, array.toString()).apply()
    }
}
