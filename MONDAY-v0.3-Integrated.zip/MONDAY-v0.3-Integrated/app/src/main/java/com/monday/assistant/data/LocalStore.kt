package com.monday.assistant.data

import android.content.Context
import com.monday.assistant.core.MondayConfig
import org.json.JSONArray
import org.json.JSONObject

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences(MondayConfig.PREFERENCES_NAME, Context.MODE_PRIVATE)

    fun getReminders(): List<Reminder> = read("reminders").mapNotNull { o ->
        val title = o.optString("title")
        if (title.isBlank()) null else Reminder(
            id = o.optInt("id"), title = title, description = o.optString("description"),
            triggerTime = o.optLong("triggerTime"), isCompleted = o.optBoolean("completed"),
            createdAt = o.optLong("createdAt")
        )
    }.sortedBy { it.triggerTime }

    fun saveReminder(item: Reminder) {
        val all = getReminders().toMutableList()
        all.removeAll { it.id == item.id }
        all.add(item)
        write("reminders", all.map { JSONObject()
            .put("id", it.id).put("title", it.title).put("description", it.description)
            .put("triggerTime", it.triggerTime).put("completed", it.isCompleted).put("createdAt", it.createdAt) })
    }

    fun deleteReminder(id: Int) = write("reminders", getReminders().filterNot { it.id == id }.map { reminderJson(it) })

    fun getNotes(): List<Note> = read("notes").mapNotNull { o ->
        val title = o.optString("title")
        if (title.isBlank()) null else Note(o.optInt("id"), title, o.optString("content"), o.optLong("createdAt"), o.optLong("updatedAt"))
    }.sortedByDescending { it.updatedAt }

    fun saveNote(note: Note) {
        val all = getNotes().toMutableList()
        all.removeAll { it.id == note.id }
        all.add(note)
        write("notes", all.map { JSONObject().put("id", it.id).put("title", it.title).put("content", it.content).put("createdAt", it.createdAt).put("updatedAt", it.updatedAt) })
    }

    fun deleteNote(id: Int) = write("notes", getNotes().filterNot { it.id == id }.map {
        JSONObject().put("id", it.id).put("title", it.title).put("content", it.content).put("createdAt", it.createdAt).put("updatedAt", it.updatedAt)
    })


    fun getEvents(): List<CalendarEvent> = read("events").mapNotNull { o ->
        val title = o.optString("title")
        if (title.isBlank()) null else CalendarEvent(
            id = o.optInt("id"), title = title, description = o.optString("description"),
            startTime = o.optLong("startTime"), endTime = o.optLong("endTime"),
            location = o.optString("location"), createdAt = o.optLong("createdAt")
        )
    }.sortedBy { it.startTime }

    fun saveEvent(event: CalendarEvent) {
        val all = getEvents().toMutableList()
        all.removeAll { it.id == event.id }
        all.add(event)
        write("events", all.map { JSONObject().put("id", it.id).put("title", it.title)
            .put("description", it.description).put("startTime", it.startTime)
            .put("endTime", it.endTime).put("location", it.location).put("createdAt", it.createdAt) })
    }

    fun deleteEvent(id: Int) = write("events", getEvents().filterNot { it.id == id }.map {
        JSONObject().put("id", it.id).put("title", it.title).put("description", it.description)
            .put("startTime", it.startTime).put("endTime", it.endTime)
            .put("location", it.location).put("createdAt", it.createdAt)
    })

    private fun reminderJson(r: Reminder) = JSONObject().put("id", r.id).put("title", r.title)
        .put("description", r.description).put("triggerTime", r.triggerTime)
        .put("completed", r.isCompleted).put("createdAt", r.createdAt)

    private fun read(key: String): List<JSONObject> {
        val array = JSONArray(prefs.getString(key, "[]"))
        return (0 until array.length()).mapNotNull { array.optJSONObject(it) }
    }

    private fun write(key: String, rows: List<JSONObject>) {
        val array = JSONArray()
        rows.forEach { array.put(it) }
        prefs.edit().putString(key, array.toString()).apply()
    }
}
