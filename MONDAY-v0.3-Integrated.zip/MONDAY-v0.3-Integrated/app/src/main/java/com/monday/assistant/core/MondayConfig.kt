package com.monday.assistant.core

object MondayConfig {
    const val APP_NAME = "MONDAY"
    const val APP_VERSION = "0.2"
    const val USER_TITLE = "Sir"
    const val PREFERENCES_NAME = "monday_local_data"
    const val REMINDER_CHANNEL_ID = "monday_reminders"
    const val REMINDER_CHANNEL_NAME = "MONDAY Reminders"
    const val THEME_BACKGROUND = 0xFF030A14
    const val THEME_PRIMARY = 0xFF39D8FF
}
