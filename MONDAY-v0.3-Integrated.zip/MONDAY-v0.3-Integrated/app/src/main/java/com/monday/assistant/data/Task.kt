package com.monday.assistant.data

data class Task(
    val id: Int,
    val title: String,
    val dueTime: Long = 0L,
    val isDone: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
