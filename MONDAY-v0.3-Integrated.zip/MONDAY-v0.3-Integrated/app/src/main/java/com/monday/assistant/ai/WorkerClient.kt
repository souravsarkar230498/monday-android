package com.monday.assistant.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Calls the user's Cloudflare Worker. Gemini credentials remain server-side. */
class WorkerClient(
    private val endpoint: String = "https://tiny-bush-c23monday-ai-brain.souravsarkar230498.workers.dev/chat"
) {
    suspend fun chat(message: String, history: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 60_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
        }
        try {
            val turns = JSONArray()
            history.takeLast(12).forEach { (role, text) ->
                turns.put(JSONObject().put("role", role).put("text", text))
            }
            val payload = JSONObject().put("message", message).put("history", turns)
            connection.outputStream.use { it.write(payload.toString().toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("MONDAY AI server returned HTTP $code: ${body.take(300)}")
            val json = JSONObject(body)
            json.optString("reply").takeIf { it.isNotBlank() }
                ?: throw IllegalStateException("The AI server returned an empty reply.")
        } finally {
            connection.disconnect()
        }
    }
}
