package com.monday.assistant.notifications

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject

class MondayNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val body = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isBlank() && body.isBlank()) return
        val prefs = getSharedPreferences("monday_local_data", MODE_PRIVATE)
        val rows = JSONArray(prefs.getString("recent_notifications", "[]"))
        val updated = JSONArray().put(JSONObject().put("app", sbn.packageName).put("title", title).put("body", body).put("time", sbn.postTime))
        for (i in 0 until minOf(rows.length(), 39)) updated.put(rows.getJSONObject(i))
        prefs.edit().putString("recent_notifications", updated.toString()).apply()
    }
}
