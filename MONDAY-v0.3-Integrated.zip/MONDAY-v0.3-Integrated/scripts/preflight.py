from pathlib import Path
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
manifest = root / "app/src/main/AndroidManifest.xml"
ET.parse(manifest)
checks = {
    "Worker client": root / "app/src/main/java/com/monday/assistant/ai/WorkerClient.kt",
    "Weather client": root / "app/src/main/java/com/monday/assistant/weather/WeatherClient.kt",
    "Offline model runtime": root / "app/src/main/java/com/monday/assistant/offline/OfflineModel.kt",
    "Calendar integration": root / "app/src/main/java/com/monday/assistant/calendar/DeviceCalendarSync.kt",
    "Notification listener": root / "app/src/main/java/com/monday/assistant/notifications/MondayNotificationListener.kt",
    "Wake-word service": root / "app/src/main/java/com/monday/assistant/wakeword/WakeWordService.kt",
    "Tasks model": root / "app/src/main/java/com/monday/assistant/data/Task.kt",
    "Reminder reboot recovery": root / "app/src/main/java/com/monday/assistant/reminders/ReminderBootReceiver.kt",
}
for name, path in checks.items():
    if not path.is_file():
        raise SystemExit(f"FAIL: missing {name}: {path}")

worker = checks["Worker client"].read_text()
if 'put("role", role).put("text", text)' not in worker or '/chat' not in worker:
    raise SystemExit("FAIL: Worker payload schema is not the tested {role,text} format")
manifest_text = manifest.read_text()
for required in ["RECORD_AUDIO", "FOREGROUND_SERVICE_MICROPHONE", "WAKE_LOCK", "READ_CALENDAR", "WRITE_CALENDAR", "BIND_NOTIFICATION_LISTENER_SERVICE", "RECEIVE_BOOT_COMPLETED", "BOOT_COMPLETED"]:
    if required not in manifest_text:
        raise SystemExit(f"FAIL: missing manifest permission/service declaration: {required}")
build = (root / "app/build.gradle.kts").read_text()
if "dev.ffmpegkit-maintained:llama-android:0.1.1" not in build:
    raise SystemExit("FAIL: offline llama.cpp dependency missing")
main = (root / "app/src/main/java/com/monday/assistant/MainActivity.kt").read_text()
for feature in ['"CHAT"', '"WEATHER"', '"TASKS"', '"REMINDERS"', '"NOTES"', '"CALENDAR"', '"ALERTS"', '"SETTINGS"']:
    if feature not in main:
        raise SystemExit(f"FAIL: missing app screen {feature}")
if "kotlinx-coroutines-android" not in build:
    raise SystemExit("FAIL: explicit Android coroutines dependency missing")
workflow = (root / ".github/workflows/android.yml").read_text()
for required in ["assembleDebug", "upload-artifact@v4", "app/build/outputs/apk/debug/app-debug.apk"]:
    if required not in workflow:
        raise SystemExit(f"FAIL: GitHub Actions build workflow missing {required}")
print("MONDAY preflight passed: manifest, Worker schema, feature modules, permissions, dependencies and APK workflow present.")
