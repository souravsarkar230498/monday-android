# MONDAY Android — v0.1 starter

A first native Android prototype for the MONDAY assistant concept.

## Included in v0.1
- Futuristic blue HUD-style home screen
- MONDAY identity and status
- Android Text-to-Speech greeting using the device's available UK English voice
- GitHub Actions workflow that builds a debug APK in the cloud

## Important limitations
This is a UI + basic speech prototype, not the complete AI assistant yet. It does not currently include an AI API, speech recognition, wake-word detection, alarms, phone-call behaviour, or a local offline language model. Those will be added in later milestones with the required permissions and testing.

## Build on GitHub using only your phone
1. Create a **private** GitHub repository named `monday-android`.
2. Upload the contents of this folder to the repository root (not the containing folder).
3. Open the repository's **Actions** tab.
4. If prompted, enable GitHub Actions.
5. Open **Build MONDAY Android APK** and tap **Run workflow** (or push to `main`).
6. When the run finishes, open the run and download the `MONDAY-debug-apk` artifact.
7. Extract the downloaded ZIP on your phone and install `app-debug.apk`. Android may ask you to allow installation from that browser/file manager.

## Voice
The app requests the Android device's installed UK English TTS voice. The exact accent and quality depend on the voice engine installed on the phone. A JARVIS-style custom voice can be integrated later.
